<?php
$ms_devMode = 1; // In most scenarios it's safe to leave this on 0
$ms_hostName = "localhost"; // Your host name or IP address
$ms_databaseName = "shiftdev_codetrack"; // Your MySQL database name
$ms_username = "root"; // Your MySQL user account name
$ms_password = ""; // Your MySQL user account password
$ms_port = 3307; // Your MySQL server port - default is 3306 unless you've changed it like I have

$gmod_path = "../../../Steam/gmod_development/garrysmod/addons/";
$project_folder = "../../Shift_Projects/";
?>